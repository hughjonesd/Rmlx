.. _losses:

.. currentmodule:: mlx.nn.losses

Loss Functions
--------------

.. autosummary::
   :toctree: _autosummary_functions
   :template: nn-module-template.rst

   binary_cross_entropy
   cosine_similarity_loss
   cross_entropy
   gaussian_nll_loss
   hinge_loss
   huber_loss
   kl_div_loss
   l1_loss
   log_cosh_loss
   margin_ranking_loss
   mse_loss
   nll_loss
   smooth_l1_loss
   triplet_loss