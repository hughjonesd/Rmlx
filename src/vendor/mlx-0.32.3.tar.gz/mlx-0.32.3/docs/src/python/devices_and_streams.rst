.. _devices_and_streams:

Devices and Streams
===================

.. currentmodule:: mlx.core

.. autosummary::
  :toctree: _autosummary

   Device
   Stream
   ThreadLocalStream
   default_device
   set_default_device
   default_stream
   new_stream
   new_thread_local_stream
   new_thread_unsafe_stream
   set_default_stream
   stream
   synchronize
   clear_streams
   device_count
   device_info
