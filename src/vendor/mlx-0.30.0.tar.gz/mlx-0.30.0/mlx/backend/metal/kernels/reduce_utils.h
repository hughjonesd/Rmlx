// Copyright © 2024 Apple Inc.

#pragma once

#include "mlx/backend/metal/kernels/atomic.h"
#include "mlx/backend/metal/kernels/reduction/ops.h"
