.. _fast:

Fast
====

.. currentmodule:: mlx.core.fast

.. autosummary:: 
  :toctree: _autosummary

  rms_norm
  layer_norm
  rope
  scaled_dot_product_attention
  metal_kernel
  cuda_kernel
