.. _transforms:

Transforms
==========

.. currentmodule:: mlx.core

.. autosummary::
  :toctree: _autosummary

   eval
   async_eval
   compile
   custom_function
   disable_compile
   enable_compile
   grad
   value_and_grad
   jvp
   vjp
   vmap
