// Copyright © 2025 Apple Inc.

namespace mlx::core {

const char* version() {
  return MLX_VERSION;
}

} // namespace mlx::core
