// Copyright © 2025 Apple Inc.

#include "mlx/backend/cuda/cuda.h"

namespace mlx::core::cu {

bool is_available() {
  return true;
}

} // namespace mlx::core::cu
