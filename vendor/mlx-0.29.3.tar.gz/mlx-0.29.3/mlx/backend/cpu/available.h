// Copyright © 2025 Apple Inc.

#pragma once

namespace mlx::core::cpu {

bool is_available();

} // namespace mlx::core::cpu
