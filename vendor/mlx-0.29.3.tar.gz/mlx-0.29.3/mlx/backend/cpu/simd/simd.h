#pragma once

#include "mlx/backend/cpu/simd/math.h"
#include "mlx/backend/cpu/simd/type.h"
