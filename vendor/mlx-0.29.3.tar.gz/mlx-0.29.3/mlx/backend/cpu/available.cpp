// Copyright © 2025 Apple Inc.

#include "mlx/backend/cpu/available.h"

namespace mlx::core::cpu {

bool is_available() {
  return true;
}

} // namespace mlx::core::cpu
