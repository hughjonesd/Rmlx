// Copyright © 2025 Apple Inc.

#pragma once

namespace mlx::core::gpu {

bool is_available();

} // namespace mlx::core::gpu
