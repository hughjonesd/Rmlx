Optimizer
=========

.. currentmodule:: mlx.optimizers

.. autoclass:: Optimizer 


   .. rubric:: Attributes

   .. autosummary::
      :toctree: _autosummary

      Optimizer.state
   
   .. rubric:: Methods

   .. autosummary::
      :toctree: _autosummary
   
      Optimizer.apply_gradients
      Optimizer.init
      Optimizer.update
