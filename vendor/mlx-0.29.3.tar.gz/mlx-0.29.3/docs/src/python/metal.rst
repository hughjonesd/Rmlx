Metal
=====

.. currentmodule:: mlx.core.metal

.. autosummary::
  :toctree: _autosummary

  is_available
  device_info
  start_capture
  stop_capture
