.. _devices_and_streams:

Devices and Streams
===================

.. currentmodule:: mlx.core

.. autosummary::
  :toctree: _autosummary

   Device
   Stream
   default_device
   set_default_device
   default_stream
   new_stream
   set_default_stream
   stream
   synchronize
