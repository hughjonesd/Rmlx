CUDA
=====

.. currentmodule:: mlx.core.cuda

.. autosummary::
  :toctree: _autosummary

  is_available
